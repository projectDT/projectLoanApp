package com.Camunda.project.LoanApproval;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "LoanApproval"; // BPMN Process ID

}
