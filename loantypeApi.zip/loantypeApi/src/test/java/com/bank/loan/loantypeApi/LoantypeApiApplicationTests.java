package com.bank.loan.loantypeApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoantypeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
