package com.bank.loan.loantypeApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class LoanService {
	@Autowired
	private LoanRepository loanRepository;
	
	//getting all loan record by using the method findaAll() of CrudRepository  
	public List<LoanEntity> getAllLoanTypes()   
	{  
	List<LoanEntity> loan = new ArrayList<LoanEntity>();  
	loanRepository.findAll().forEach(loans -> loan.add(loans));  
	return loan;  
	}
	
	//getting a specific record by using the method findById() of CrudRepository
		public Optional<LoanEntity> getLoanById(int id) throws NoSuchElementFoundException {
		Optional<LoanEntity> loanentity =	loanRepository.findById(id);
		
		if(!loanentity.isPresent()) {
			throw new NoSuchElementFoundException(null, "loan id: '" +id+ "' not found in repository'");
		}
		return loanentity;
		}

}
