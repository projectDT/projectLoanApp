package com.bank.loan.loantypeApi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@Entity // This tells Hibernate to make a table out of this class
@JsonPropertyOrder({"id"})
@Table(name="table2")
public class LoanEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column  
	private int id;
	@Column  
	private String loan_type;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLoan_type() {
		return loan_type;
	}
	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}
}
