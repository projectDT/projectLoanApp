package com.api.loan.LoanParameters;

public class EligibilityCriteriaBVO {
	
	private Integer minAge;
	private Integer maxAge;
	private Integer salary;
	
	public EligibilityCriteriaBVO() {
		
	}
	
	public Integer getMinAge() {
		return minAge;
	}
	public void setMinAge(Integer minAge) {
		this.minAge = minAge;
	}
	public Integer getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(Integer maxAge) {
		this.maxAge = maxAge;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
	
	
	
}
