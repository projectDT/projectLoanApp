package com.api.loan.LoanParameters;

public class InterestDetailsBVO {
	
	private Float rate;
	
	public InterestDetailsBVO() {
	}
	public Float getRate() {
		return rate;
	}

	public void setRate(Float rate) {
		this.rate = rate;
	}

}
