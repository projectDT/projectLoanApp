package com.api.loan.LoanParameters;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DetailsRepository extends JpaRepository<DetailsEntity, Integer> {

}
