package com.api.loan.LoanParameters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class DetailsService {
	
	@Autowired
	private DetailsRepository repo;

	 public List<DetailsEntity> listAll() {
	        return repo.findAll();
	    }
	     
	    public void save(DetailsEntity details) {
	        repo.save(details);
	    }
	     
	    public DetailsEntity get(Integer id) {
	        return repo.findById(id).get();
	    }
	     
	    public void delete(Integer id) {
	        repo.deleteById(id);
	    }
}
