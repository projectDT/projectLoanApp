package com.api.loan.LoanParameters;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="table1")
public class DetailsEntity {

	private Integer id;
	private String loan;
	private String documents;
	private Float interest;
	private Integer eligibility;
	private Integer eligibility2;
	private Integer eligibility3;
	
	
	public DetailsEntity() {
	}

	public DetailsEntity(Integer id, String loan, String documents, Float interest, Double salary, Integer eligibility,Integer eligibility2, Integer eligibility3) {
		
		super();
		this.id = id;
		this.loan = loan;
		this.documents = documents;
		this.setInterest(interest);
		this.setEligibility(eligibility);
		this.setEligibility2(eligibility2);
		this.setEligibility3(eligibility3);
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}



	/*public double getSalary() {
		return eligibilityCriteria;
	}

	public void setSalary(double salary) {
		this.eligibilityCriteria = salary;
	}*/

	public Float getInterest() {
		return interest;
	}

	public void setInterest(Float interest) {
		this.interest = interest;
	}

	public Integer getEligibility() {
		return eligibility;
	}

	public void setEligibility(Integer eligibility) {
		this.eligibility = eligibility;
	}

	public Integer getEligibility2() {
		return eligibility2;
	}

	public void setEligibility2(Integer eligibility2) {
		this.eligibility2 = eligibility2;
	}

	public Integer getEligibility3() {
		return eligibility3;
	}

	public void setEligibility3(Integer eligibility3) {
		this.eligibility3 = eligibility3;
	}

	public String getLoan() {
		return loan;
	}

	public void setLoan(String loan) {
		this.loan = loan;
	}

	

	

}
