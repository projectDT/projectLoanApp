package com.api.loan.LoanParameters;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Controller
@RestController
public class DetailsController {
	
	@Autowired
	private DetailsService service;
	
	@GetMapping("/details")
	public List<DetailsEntity> list() {
	    return service.listAll();
	}
	
	@GetMapping("/details/{id}")
	public ResponseEntity<DetailsBVO> get(@PathVariable Integer id) {
	    try {
	        DetailsEntity details = service.get(id);
	        InterestDetailsBVO interestDetails= new InterestDetailsBVO(); 
	        interestDetails.setRate(details.getInterest());
	        
	        EligibilityCriteriaBVO eligibilityCriteria= new EligibilityCriteriaBVO();
	        eligibilityCriteria.setMinAge(details.getEligibility());
	        eligibilityCriteria.setMaxAge(details.getEligibility2());
	        eligibilityCriteria.setSalary(details.getEligibility3());
	        
	        DetailsBVO detailsBVO = new DetailsBVO(details.getId(), details.getLoan(),details.getDocuments(),interestDetails,eligibilityCriteria);
	       
	        return new ResponseEntity<DetailsBVO>(detailsBVO, HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<DetailsBVO>(HttpStatus.NOT_FOUND);
	    }      
	}
	

}
