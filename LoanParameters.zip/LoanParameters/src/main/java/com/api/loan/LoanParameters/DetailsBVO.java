package com.api.loan.LoanParameters;

public class DetailsBVO {

	private Integer id;
	private String loan;
	private String documents;
	private InterestDetailsBVO interestDetails;
	private EligibilityCriteriaBVO eligibilityCriteria;
	//private Double salary;

	public DetailsBVO() {
	}

	public DetailsBVO(Integer id,String loan, String documents, InterestDetailsBVO interestDetails, EligibilityCriteriaBVO eligibilityCriteria) {

		super();
		this.id = id;
		this.loan = loan;
		this.documents = documents;
		this.setInterestDetails(interestDetails);
		this.setEligibilityCriteria(eligibilityCriteria);
		//this.salary = salary;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}

	/*public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}*/

	public InterestDetailsBVO getInterestDetails() {
		return interestDetails;
	}

	public void setInterestDetails(InterestDetailsBVO interestDetails) {
		this.interestDetails = interestDetails;
	}

	public EligibilityCriteriaBVO getEligibilityCriteria() {
		return eligibilityCriteria;
	}

	public void setEligibilityCriteria(EligibilityCriteriaBVO eligibilityCriteria) {
		this.eligibilityCriteria = eligibilityCriteria;
	}

	public String getLoan() {
		return loan;
	}

	public void setLoan(String loan) {
		this.loan = loan;
	}

}
