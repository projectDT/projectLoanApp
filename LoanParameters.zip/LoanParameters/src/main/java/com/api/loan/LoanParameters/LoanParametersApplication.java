package com.api.loan.LoanParameters;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanParametersApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanParametersApplication.class, args);
	}

}
