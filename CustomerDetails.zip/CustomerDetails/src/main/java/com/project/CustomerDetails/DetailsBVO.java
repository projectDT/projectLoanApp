package com.project.CustomerDetails;

public class DetailsBVO {
	
	private Integer id;
	private BasicInfoBVO basicInfo; 
	private String loanTenure; 
	private CommDetailsBVO commDetails;
	private Integer loanIdSelected;
	
	public DetailsBVO() {
	}

	public DetailsBVO(Integer id, BasicInfoBVO basicInfo, String loanTenure, CommDetailsBVO commDetails, Integer loanIdSelected) {
		super();
		this.id = id;
		this.setBasicInfo(basicInfo);		 
		this.loanTenure = loanTenure;
		this.setCommDetails(commDetails);
		this.loanIdSelected = loanIdSelected;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public BasicInfoBVO getBasicInfo() {
		return basicInfo;
	}

	public void setBasicInfo(BasicInfoBVO basicInfo) {
		this.basicInfo = basicInfo;
	}

	public String getLoanTenure() {
		return loanTenure;
	}

	public void setLoanTenure(String loanTenure) {
		this.loanTenure = loanTenure;
	}

	public CommDetailsBVO getCommDetails() {
		return commDetails;
	}

	public void setCommDetails(CommDetailsBVO commDetails) {
		this.commDetails = commDetails;
	}

	public Integer getLoanIdSelected() {
		return loanIdSelected;
	}

	public void setLoanIdSelected(Integer loanIdSelected) {
		this.loanIdSelected = loanIdSelected;
	}
	
	
}
